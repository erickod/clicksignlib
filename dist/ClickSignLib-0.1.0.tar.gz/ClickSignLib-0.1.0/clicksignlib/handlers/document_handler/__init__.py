from .document_handler import DocumentHandler

__all__ = [
    "DocumentHandler",
]
