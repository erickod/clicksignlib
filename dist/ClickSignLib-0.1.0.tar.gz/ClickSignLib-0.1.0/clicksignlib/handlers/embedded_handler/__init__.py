from .embedded_handler import EmbeddedHandler

__all__ = [
    "EmbeddedHandler",
]
