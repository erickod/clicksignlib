from .result import Result

__all__ = ["Result"]
