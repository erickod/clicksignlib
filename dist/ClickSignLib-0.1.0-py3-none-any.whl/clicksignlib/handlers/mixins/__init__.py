from .endpoint_mixin import EndpointMixin

__all__ = [
    "EndpointMixin",
]
